class AppConfig {
  static const String baseUrl = 'http://10.0.2.2:5000'; // emulador Android
}
