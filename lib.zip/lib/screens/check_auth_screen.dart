import 'package:flutter/material.dart';
import '../services/auth_service.dart';

class CheckAuthScreen extends StatelessWidget {
  const CheckAuthScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return FutureBuilder<bool>(
      future: AuthService().isLoggedIn(),
      builder: (context, snapshot) {
        if (snapshot.connectionState == ConnectionState.waiting) {
          return const Scaffold(
            body: Center(child: CircularProgressIndicator()),
          );
        }

        if (snapshot.data == true) {
          Future.microtask(
            () => Navigator.pushReplacementNamed(context, '/home'),
          );
        } else {
          Future.microtask(
            () => Navigator.pushReplacementNamed(context, '/login'),
          );
        }

        return const SizedBox.shrink();
      },
    );
  }
}
